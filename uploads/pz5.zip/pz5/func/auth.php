<!-- Цю форму видно, якщо користувач НЕ авторизований -->
<form method="POST" action="../func/login.php">
    <input type="text" name="username" placeholder="Введіть логін">
    <input type="password" name="password" placeholder="Password">
    <button type="submit" name="submit">Login</button>
</form>
<?php
< !--Цю форму видно, якщо користувач авторизований-- >
<form method = "" action = "" enctype = "multipart/form-data" >
    <input type = "file" name = "file" >
    <input type = "submit" value = "Відправити" >
</form >
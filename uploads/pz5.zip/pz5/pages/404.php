<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Сторінку не знайдено</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<p>Вважаємо, що було невірно введено адресу в браузері і тому потрібно повернутись на головну сторінку:
    <a href="/">Натисни мене</a>
</p>
</body>
</html>